Ini merupakan hasil final kami dimana tadi 
terdapat beberapa revisi setelah presentasi
(contoh : typo, kesalahan gambar)